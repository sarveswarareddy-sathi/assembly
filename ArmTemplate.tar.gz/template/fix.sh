echo "PATH=$PATH:$HOME/template/" >> $HOME/.bashrc
mkdir $HOME/project
